# Student template for CSE 130-02, Fall 2019.

This template instantiates all of the assignment directories (asgn0-asgn4),
each with a 0-byte README.md in them. It also includes a .gitignore file.

## Continuous integration

Continuous integration (automated testing) is done by a .gitlab-ci.yml
file that's provided in the root directory. This is used by GitLab to
run tests on repositories. **DO NOT MODIFY OR REMOVE THIS FILE**.
