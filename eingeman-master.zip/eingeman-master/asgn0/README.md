CruzID: eingeman
eingeman@ucsc.edu
Name: Emil Ingemansson

To my knowledge there are no bugs. It builds by simply calling gmake and should work in the same manner as cat but with the name dog. 
